/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { GridmasonryComponent } from './gridmasonry.component';

describe('Component: Gridmasonry', () => {
  it('should create an instance', () => {
    let component = new GridmasonryComponent();
    expect(component).toBeTruthy();
  });
});
