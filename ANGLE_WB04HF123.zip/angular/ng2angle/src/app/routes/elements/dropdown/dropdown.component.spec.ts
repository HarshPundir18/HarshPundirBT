/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DropdownComponent } from './dropdown.component';

describe('Component: Dropdown', () => {
  it('should create an instance', () => {
    let component = new DropdownComponent();
    expect(component).toBeTruthy();
  });
});
