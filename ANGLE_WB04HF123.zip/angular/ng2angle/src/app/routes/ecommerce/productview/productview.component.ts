import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productview',
  templateUrl: './productview.component.html',
  styleUrls: ['./productview.component.scss']
})
export class ProductviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
