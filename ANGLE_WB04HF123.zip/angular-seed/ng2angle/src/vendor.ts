
import './modernizr.js'; // 'npm run modernizr' to create this file
